from django.shortcuts import render



def IceCreamShop(request):
    data = {"title": "Salama & sisters", "message": "welcome to ice cream shop"}
    return render(request, "Welcome.html", data)

def order(request):
    if request.method == 'POST':
        flavor = request.POST.get('flavor')
        quantity = int(request.POST.get('quantity', 1))
        # Use the price of the selected flavor to calculate the total price
        if flavor == 'vanilla':
            price = 1.50
        elif flavor == 'chocolate':
            price = 1.75
        elif flavor == 'strawberry':
            price = 1.60
        else:
            price = 0  # Default price if flavor is not recognized

        total_price = price * quantity
        return render(request, 'order.html', {'flavor': flavor, 'quantity': quantity, 'total_price': total_price})
    return render(request, 'welcome.html')