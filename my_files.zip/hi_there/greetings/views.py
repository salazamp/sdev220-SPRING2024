from django.shortcuts import render

# Create your views here.


def generalkenobi(request):
    data = {"title": "hello", "message": "why hello there"}
    return render(request, "say.html", data)

