from django.shortcuts import render

def placeholder_view(request):
    context = {
        'title': 'Django Placeholder',
        'description': 'This is a Django app that uses placeholders in an HTML template.',
        'author': 'Your Name',
        'date_created': 'February 18, 2024',
        'version': '1.0'
    }
    return render(request, 'placeholder/index.html', context)