

import emoji

def message():
	return emoji.emojize(":waving_hand: :globe_showing_Americas:")


	if _name_ == "_main_":
	   print(message())
	   

 